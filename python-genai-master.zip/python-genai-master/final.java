package stepdefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.lang.Process;
import java.lang.Runtime;
import java.io.*;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.IdTokenCredentials;
import com.google.auth.oauth2.IdTokenProvider;
import com.google.auth.oauth2.IdTokenProvider.Option;
import com.google.auth.oauth2.IdToken;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.*;
import io.restassured.specification.RequestSpecification;
import io.restassured.http.ContentType;
// import com.google.api.client.json.gson.GsonFactory;
public class Products{
    // private static final String BASE_URL = "https://flask-demo-t3rinopc7q-uc.a.run.app"; // Replace with your API base URL
    private Response response;
    private RequestSpecification request;
    String base_url;
    // private static AccessToken token=null;

    // static{
    //     try{
    //     GoogleCredentials credentials = GoogleCredentials.getApplicationDefault();
    //     if (!(credentials instanceof IdTokenProvider)) {
    //         throw new IllegalArgumentException("Credentials are not an instance of IdTokenProvider.");
    //     }

    //     token = credentials.getAccessToken();
    //     }catch(Exception ex){

    //     }
    // }

//     @Given("a user exists with ID {int}")
//     public void aUserExistsWithID(int userId) {
//         // Assuming the API already has users, no action needed here for this example
//     }

//     @When("I send a GET request to {string}")
//     public void iSendAGETRequestTo(String endpoint) throws Exception {
//         List<String> targetServiceScopes = Arrays.asList(
//             "https://www.googleapis.com/auth/cloud-platform", // Common broad scope
//             "https://www.googleapis.com/auth/cloud-platform.apis", // For accessing other services
//             "https://www.googleapis.com/auth/devstorage.full_control" // Example for Cloud Storage
//             // ... other scopes as needed
//         );
//         GoogleCredentials googleCredentials = GoogleCredentials.getApplicationDefault();
//         GoogleCredentials scopedCredentials = googleCredentials.createScoped(targetServiceScopes);
//         if (!(scopedCredentials instanceof IdTokenProvider)) {
//             throw new IllegalArgumentException("Credentials are not an instance of IdTokenProvider.");
//           }

//         // IdToken  idTokens = googleCredentials.getIdToken();
//         // System.out.println(idTokens.getTokenValue());
//         IdTokenCredentials idTokenCredentials =
//             IdTokenCredentials.newBuilder()
//                 .setIdTokenProvider((IdTokenProvider) scopedCredentials)
//                 .setTargetAudience(BASE_URL)
//                 // Setting the ID token options.
//                 .setOptions(Arrays.asList(Option.FORMAT_FULL, Option.LICENSES_TRUE))
//                 .build();
//         String idToken = idTokenCredentials.refreshAccessToken().getTokenValue();
//         // System.out.println(idToken);
//         response = RestAssured.given()
//                 .baseUri(BASE_URL)
//                 .header("Authorization","Bearer "+idToken)
//                 .when()
//                 .get(endpoint);
//     }
    // @Then("the response status code should be {int}")
    // public void theResponseStatusCodeShouldBe(int statusCode) {
    //     response.then().statusCode(statusCode);
    // }

    @Given("the base URL is {string}")
    public void setBaseUrl(String baseUrl) {
        base_url =  baseUrl;
    }

     @When("a POST request is sent to {string} with the following XML body:")
    public void sendPostRequest(String endpoint,String body) throws Exception{
        List<String> targetServiceScopes = Arrays.asList(
            "https://www.googleapis.com/auth/cloud-platform", // Common broad scope
            "https://www.googleapis.com/auth/cloud-platform.apis", // For accessing other services
            "https://www.googleapis.com/auth/devstorage.full_control" // Example for Cloud Storage
            // ... other scopes as needed
        );
        GoogleCredentials googleCredentials = GoogleCredentials.getApplicationDefault();
        GoogleCredentials scopedCredentials = googleCredentials.createScoped(targetServiceScopes);
        if (!(scopedCredentials instanceof IdTokenProvider)) {
            throw new IllegalArgumentException("Credentials are not an instance of IdTokenProvider.");
          }

        // IdToken  idTokens = googleCredentials.getIdToken();
        // System.out.println(idTokens.getTokenValue());
        IdTokenCredentials idTokenCredentials =
            IdTokenCredentials.newBuilder()
                .setIdTokenProvider((IdTokenProvider) scopedCredentials)
                .setTargetAudience("https://flask-demo-t3rinopc7q-uc.a.run.app")
                // Setting the ID token options.
                .setOptions(Arrays.asList(Option.FORMAT_FULL, Option.LICENSES_TRUE))
                .build();
        String idToken = idTokenCredentials.refreshAccessToken().getTokenValue();

        System.out.println(body);
        request = RestAssured.given()
            .contentType(ContentType.XML)
            .baseUri(base_url)
            .header("Authorization","Bearer "+idToken)
            .header("Content-Type", "application/xml")
            .body(body);
        response = request.post(endpoint);
    }

    @Then("the response status code should be {int}")
    public void verifyStatusCode(int statusCode) {
        response.then().statusCode(statusCode);
    }

//     @Given("the base URL is https://flask-demo-t3rinopc7q-uc.a.run.app")
//     public void setBaseUrl() {
//         RestAssured.baseURI = "https://flask-demo-t3rinopc7q-uc.a.run.app";
//     }

//     @When("a POST request is sent to /transactions/add with the following body:")
//     public void sendPostRequest(String body) {
//         request = RestAssured.given().header("Content-Type", "application/json").body(body);
//         response = request.post("/transactions/add");
//     }

//     @Then("the response status code should be {int}")
//     public void verifyStatusCode(int statusCode) {
//         response.then().statusCode(equalTo(statusCode));
//     }

}
