```java
package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;

import static org.hamcrest.Matchers.equalTo;

public class Products {

    private Response response;
    private RequestSpecification requestSpecification;

    @Given("the API endpoint is {string}")
    public void the_API_endpoint_is(String endpoint) {
        requestSpecification = RestAssured.given();
        requestSpecification.baseUri("http://localhost:5000");
        requestSpecification.basePath(endpoint);
    }

    @When("a GET request is sent")
    public void a_GET_request_is_sent() {
        response = requestSpecification.get();
    }

    @When("a POST request is sent with the following body:")
    public void a_POST_request_is_sent_with_the_following_body(String body) {
        response = requestSpecification.body(body).post();
    }

    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(int statusCode) {
        Assert.assertEquals(statusCode, response.getStatusCode());
    }

    @And("the response body should be a list of transactions")
    public void the_response_body_should_be_a_list_of_transactions() {
        response.then().body("size()", equalTo(3));
    }

    @And("the response body should be a transaction with the ID {string}")
    public void the_response_body_should_be_a_transaction_with_the_ID(String id) {
        response.then().body("id", equalTo(id));
    }

    @And("the response body should contain the new transaction")
    public void the_response_body_should_contain_the_new_transaction() {
        response.then().body("transaction_id", equalTo("67890"));
    }

    @And("the response body should contain an error message")
    public void the_response_body_should_contain_an_error_message() {
        response.then().body("error", equalTo("transaction id not found"));
    }
}
```