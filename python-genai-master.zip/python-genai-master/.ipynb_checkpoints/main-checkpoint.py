import crewai
import base64
import vertexai
import os
import crewai_tools
from vertexai.generative_models import GenerativeModel, Part
import vertexai.preview.generative_models as generative_models
from crewai import Task,Agent,Crew,Process
from textwrap import dedent
from crewai_tools import FileReadTool
# from langchain.llms import VertexAI
# from langchain_community.llms import VertexAI
from langchain_google_vertexai import VertexAI

example_step_def=dedent("""   
package stepdefinations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.lang.Process;
import java.lang.Runtime;
import java.io.*;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.IdTokenCredentials;
import com.google.auth.oauth2.IdTokenProvider;
import com.google.auth.oauth2.IdTokenProvider.Option;
import com.google.auth.oauth2.IdToken;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.*;
import io.restassured.specification.RequestSpecification;
import io.restassured.http.ContentType;
// import com.google.api.client.json.gson.GsonFactory;
public class Products{
    // private static final String BASE_URL = "https://flask-demo-t3rinopc7q-uc.a.run.app"; // Replace with your API base URL
    private Response response;
    private RequestSpecification request;
    String base_url;
    // private static AccessToken token=null;
    
    // static{
    //     try{
    //     GoogleCredentials credentials = GoogleCredentials.getApplicationDefault();
    //     if (!(credentials instanceof IdTokenProvider)) {
    //         throw new IllegalArgumentException("Credentials are not an instance of IdTokenProvider.");
    //     }
        
    //     token = credentials.getAccessToken();
    //     }catch(Exception ex){

    //     }
    // }

//     @Given("a user exists with ID {int}")
//     public void aUserExistsWithID(int userId) {
//         // Assuming the API already has users, no action needed here for this example
//     }

//     @When("I send a GET request to {string}")
//     public void iSendAGETRequestTo(String endpoint) throws Exception {
//         List<String> targetServiceScopes = Arrays.asList(
//             "https://www.googleapis.com/auth/cloud-platform", // Common broad scope
//             "https://www.googleapis.com/auth/cloud-platform.apis", // For accessing other services
//             "https://www.googleapis.com/auth/devstorage.full_control" // Example for Cloud Storage
//             // ... other scopes as needed
//         );
//         GoogleCredentials googleCredentials = GoogleCredentials.getApplicationDefault();
//         GoogleCredentials scopedCredentials = googleCredentials.createScoped(targetServiceScopes);
//         if (!(scopedCredentials instanceof IdTokenProvider)) {
//             throw new IllegalArgumentException("Credentials are not an instance of IdTokenProvider.");
//           }

//         // IdToken  idTokens = googleCredentials.getIdToken();
//         // System.out.println(idTokens.getTokenValue());
//         IdTokenCredentials idTokenCredentials =
//             IdTokenCredentials.newBuilder()
//                 .setIdTokenProvider((IdTokenProvider) scopedCredentials)
//                 .setTargetAudience(BASE_URL)
//                 // Setting the ID token options.
//                 .setOptions(Arrays.asList(Option.FORMAT_FULL, Option.LICENSES_TRUE))
//                 .build();
//         String idToken = idTokenCredentials.refreshAccessToken().getTokenValue();
//         // System.out.println(idToken);
//         response = RestAssured.given()
//                 .baseUri(BASE_URL)
//                 .header("Authorization","Bearer "+idToken)
//                 .when()
//                 .get(endpoint);
//     }
    // @Then("the response status code should be {int}")
    // public void theResponseStatusCodeShouldBe(int statusCode) {
    //     response.then().statusCode(statusCode);
    // }
    
    @Given("the base URL is {string}")
    public void setBaseUrl(String baseUrl) {
        base_url =  baseUrl;
    }
    
     @When("a POST request is sent to {string} with the following body:")
    public void sendPostRequest(String endpoint,String body) throws Exception{
        List<String> targetServiceScopes = Arrays.asList(
            "https://www.googleapis.com/auth/cloud-platform", // Common broad scope
            "https://www.googleapis.com/auth/cloud-platform.apis", // For accessing other services
            "https://www.googleapis.com/auth/devstorage.full_control" // Example for Cloud Storage
            // ... other scopes as needed
        );
        GoogleCredentials googleCredentials = GoogleCredentials.getApplicationDefault();
        GoogleCredentials scopedCredentials = googleCredentials.createScoped(targetServiceScopes);
        if (!(scopedCredentials instanceof IdTokenProvider)) {
            throw new IllegalArgumentException("Credentials are not an instance of IdTokenProvider.");
          }

        // IdToken  idTokens = googleCredentials.getIdToken();
        // System.out.println(idTokens.getTokenValue());
        IdTokenCredentials idTokenCredentials =
            IdTokenCredentials.newBuilder()
                .setIdTokenProvider((IdTokenProvider) scopedCredentials)
                .setTargetAudience("https://flask-demo-t3rinopc7q-uc.a.run.app")
                // Setting the ID token options.
                .setOptions(Arrays.asList(Option.FORMAT_FULL, Option.LICENSES_TRUE))
                .build();
        String idToken = idTokenCredentials.refreshAccessToken().getTokenValue();

        System.out.println(body);
        request = RestAssured.given()
            .contentType(ContentType.JSON)
            .baseUri(base_url)
            .header("Authorization","Bearer "+idToken)
            .header("Content-Type", "application/json")
            .body(body);
        response = request.post(endpoint);
    }

    @Then("the response status code should be {int}")
    public void verifyStatusCode(int statusCode) {
        response.then().statusCode(statusCode);
    }
    
//     @Given("the base URL is https://flask-demo-t3rinopc7q-uc.a.run.app")
//     public void setBaseUrl() {
//         RestAssured.baseURI = "https://flask-demo-t3rinopc7q-uc.a.run.app";
//     }

//     @When("a POST request is sent to /transactions/add with the following body:")
//     public void sendPostRequest(String body) {
//         request = RestAssured.given().header("Content-Type", "application/json").body(body);
//         response = request.post("/transactions/add");
//     }

//     @Then("the response status code should be {int}")
//     public void verifyStatusCode(int statusCode) {
//         response.then().statusCode(equalTo(statusCode));
//     }

}
""")


example_feature=dedent("""
Feature: Add a new transaction

  Scenario: Add a new transaction successfully
    Given the base URL is 'https://flask-demo-t3rinopc7q-uc.a.run.app'
    When a POST request is sent to '/transactions/add' with the following body:
    \"""
    {
      "transaction_id":"16",
      "accno":"6",
      "amt":"2000",
      "to":"2",
      "status":"complete"
    }

    \"""
    Then the response status code should be 201
""")

vertexai.init(project="innov-ttat-7nmw-1", location="us-central1")
VertexAI.update_forward_refs()
genai = VertexAI(model_name = 'gemini-1.5-flash-001',
              temperature =0,
              top_k = 40,
              top_p = 0.95,
              max_output_tokens = 8192,
        )

#user defined python functions
def save_to_file(filename, content):
    with open(filename, 'w') as file:
        file.write(content)

def remove_first_and_last_line(input_file_path, output_file_path):
    with open(input_file_path, 'r') as file:
        lines = file.readlines()
    # Remove the first and last lines
    if len(lines) > 2:
        lines = lines[1:-1]
    else:
        # If the file has less than or equal to two lines, the result will be an empty list
        lines = []
    with open(output_file_path, 'w') as file:
        file.writelines(lines)
        
def remove_lines_before_feature(inp,oup):
    with open(inp,'r') as f_input,open(oup,'w') as f_output:
        found=False
        for line in f_input:
            if not found:
                if "Feature" in line:
                    found=True
                    f_output.write(line)
            else:
                f_output.write(line)



#Task class
class TestTasks:
    def __tip_section(self):
        return "If you do your BEST WORK, I'll give you a $10,000 commission!"

    def generate_feature(self,agent,api,api_doc,acceptance_criteria,example):
        return Task(
            description=dedent(f"""
            **Task**: [Generate the content of feature file in accordance with the users acceptance criteria ]
            **Description**: [Generate the content of feature file of java maven project to run a cucumber test case for the given 
            acceptance criteria and dont create extra scenarios]

            **Parameters**:
            -api {api}
            - api documentation: {api_doc}
            - acceptance criteria : {acceptance_criteria}
            -learn from this examples: {example}

            ******Cautions********
            main caution : only create scenarios for user given acceptance criteria and dont create extra scenarios
            only give content of scenario that user asks for in acceptance criteria never create extra scenarios please
            """
            ),
            agent=agent,
            expected_output="",
            outputs=['feature_file_content'],
        )

    def generate_stepdefinitions(self, agent,api,api_doc,feature_file_content,example):
        return Task(
        description=dedent(f"""
        **Task**: [Generate the content of step definition file named "Products.java" according to given feature_file_content of java project]
        **Description**: [Generate the content of stepdefinitionsfile "Products.java" of java maven project to run a cucumber test case for the given 
        acceptance criteria and first line use it as package stepdefinitions; **This step definition should include Google Cloud IAP authentication**. ]
        
        Rules: Never use depricated libraries and you code should not give error
        
        **Parameters**: 
        - api : {api}
        - api documentation: {api_doc}
        - feature_file_content:{feature_file_content}
        -learn from the given example {example} and produce good content
        Caution:
        1. Stricly produce the step definiton file in accordance with the feature file such that it should map with the feature file properly.
        2. Stricly produce the step definiton file in accordance with the feature file such that it should map with the feature file properly.
        3. Stricly produce the step definiton file in accordance with the feature file such that it should map with the feature file properly.
        4. dont use any methods that are not there.
        
        mapping of feature file step definition file example:
        
        


        **Note**: {self.__tip_section()}
        """
        ),
        agent=agent,
        context=feature_file_content,
        expected_output="",
        outputs=['stepdefinition_file_content'],
        )


#Agent class
class TestAgents:
    def __init__(self):
        self.genai = genai
        

    def feature_generator(self):
        return Agent(
            role=dedent(f"""Gherkin feature file generator expert"""),

            backstory=dedent(f"""You are an expert in gherkin language with full knowledge about the syntax of the gherkin language
                            and has worked in many projects to convert given english criteria to a gherkin test case content of feature file 
                            required for testing an api using cucumber bdd framework in java project  """),

            goal=dedent(f"""
                        provide the content of the feature file for the given api, documentation of the api 
                        and the acceptance criteria for the test case"""),
            verbose=True,
            max_iter=25,
            llm=self.genai,
        )
    
    def step_def_generator(self):
        return Agent(
        role=dedent(f"""Expert Java maven step definition file generator with Google Cloud IAP authentication skills"""),

        backstory=dedent(f"""You are an expert in producing the content of step definition files in Java language for APIs that require Google Cloud IAP authentication. 
        You understand the process of obtaining an ID token and using it for authorization in RESTAssured. You have experience in integrating this authentication mechanism 
        into Cucumber tests to ensure secure access to protected APIs within Google Cloud environments. 
        """),
        goal=dedent(f"""
        Provide the content of the stepdefinition file in Java language accurately with no syntax errors and including all necessary imports for Google Cloud IAP authentication. 
        """),
        verbose=True,
        max_iter=20,
        # tools=[file_read_tool],
        llm=self.genai,
        )

    def software_engineer(self):
        return Agent(
            role=dedent(f"""Expert and experianced java software developer"""),

            backstory=dedent(f"""You are the world best and finest java developer who will write codes with absolutely no errors
                             and no one is better than you """),

             goal=dedent(f"""
                        producing accurate code in accordance to the task assigned to you and also learn using the tools provided to you but dont try to replicate it"""),
            verbose=True,
            max_iter=20,
            # tools=[file_read_tool],
            llm=self.genai,
        )


print("## Welcome to Crew AI Template")
print("-------------------------------")
api = input(dedent("""Enter the base url of the api that needed to be tested   """))
api_doc = input(dedent("""Enter the documentation of the above api's representing all end points clearly   """))
acceptance_criteria= input(dedent("""Enter the test case to test clearly in plain english   """))


#declaring the agents
agents = TestAgents()
tasks = TestTasks()


#setting up the agents
# feature_agent= agents.feature_generator()
# stepdefinition_agent = agents.step_def_generator()
one_agent=agents.software_engineer()


#setting up the tasks 
generate_feature= tasks.generate_feature(
            one_agent,
            api,
            api_doc,
            acceptance_criteria,
            example_feature,
        )

generate_stepdefinitions = tasks.generate_stepdefinitions(
            one_agent,
            api,
            api_doc,
            [generate_feature],
            example_step_def,
        )


#setting up the crew
crew1 = Crew(
            agents=[one_agent],
            tasks=[generate_feature],
            verbose=True,
            process=Process.sequential,
            manager_llm=genai,
        )

crew2 = Crew(
            agents=[one_agent],
            tasks=[generate_stepdefinitions],
            verbose=True,
            manager_llm=genai,
        )



#starting the crew
feature_file_content=crew1.kickoff()
save_to_file("pre.feature",feature_file_content)
remove_first_and_last_line("pre.feature", "hello.feature")
remove_lines_before_feature("hello.feature","final.feature")
#java-bdd/java-bdd/src/test/resources/features/create_item.feature    

stepdefinition_file_content=crew2.kickoff()
save_to_file("pre.java",stepdefinition_file_content)
remove_first_and_last_line("pre.java","final.java")
#java-bdd/java-bdd/src/test/java/stepdefinations/Products.java



print("crew process complete and results are generated  .....")
    