package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.Arrays;
import java.util.List;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.IdTokenCredentials;
import com.google.auth.oauth2.IdTokenProvider;
import com.google.auth.oauth2.IdTokenProvider.Option;

public class Products {

    private Response response;
    private String idToken;

    @Given("the base URL is {string}")
    public void the_base_URL_is(String baseUrl) {
        RestAssured.baseURI = "https://flask-demo-t3rinopc7q-uc.a.run.app";
        try {
            List<String> targetServiceScopes = Arrays.asList(
                "https://www.googleapis.com/auth/cloud-platform", // Common broad scope
                "https://www.googleapis.com/auth/cloud-platform.apis", // For accessing other services
                "https://www.googleapis.com/auth/devstorage.full_control" // Example for Cloud Storage
                // ... other scopes as needed
            );
            GoogleCredentials googleCredentials = GoogleCredentials.getApplicationDefault();
            GoogleCredentials scopedCredentials = googleCredentials.createScoped(targetServiceScopes);
            IdTokenCredentials idTokenCredentials =
                IdTokenCredentials.newBuilder()
                    .setIdTokenProvider((IdTokenProvider) scopedCredentials)
                    .setTargetAudience("https://flask-demo-t3rinopc7q-uc.a.run.app") // Replace with your target audience
                    // Setting the ID token options.
                    .setOptions(Arrays.asList(Option.FORMAT_FULL, Option.LICENSES_TRUE))
                    .build();
            idToken = idTokenCredentials.refreshAccessToken().getTokenValue();
        } catch (Exception e) {
            System.err.println("Error obtaining ID token: " + e.getMessage());
            // Handle the error appropriately (e.g., throw an exception)
        }
    }

    @When("I send a GET request to transactions endpoint")
    public void i_send_a_GET_request_to_transactions_endpoint() {
        RequestSpecification request = RestAssured.given()
            .header("Authorization", "Bearer " + idToken);
        response = request.get("transactions");
    }

    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(int statusCode) {
        response.then().statusCode(statusCode);
    }
}

