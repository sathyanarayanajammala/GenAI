from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from typing import List, Dict
from config import Config

class EmbeddingsHandler:
    def __init__(self, config: Config):
        self.config = config
        self.embeddings = HuggingFaceEmbeddings(
            model_name=config.model.embedding_model,
            model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'}
        )
        self.vector_store = None
        
    def create_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Create embeddings for a list of texts"""
        return self.embeddings.embed_documents(texts)
        
    def init_vector_store(self, documents: List[Dict]):
        """Initialize FAISS vector store with documents"""
        self.vector_store = FAISS.from_documents(documents, self.embeddings)
        
    def save_vector_store(self):
        """Save vector store to disk"""
        if self.vector_store:
            self.vector_store.save_local(self.config.vector_store_path)
            
    def load_vector_store(self):
        """Load vector store from disk"""
        self.vector_store = FAISS.load_local(
            self.config.vector_store_path,
            self.embeddings
        )
        
    def search_similar(self, query: str, k: int = 5) -> List[Dict]:
        """Search for similar patents"""
        if not self.vector_store:
            return []
            
        results = self.vector_store.similarity_search_with_score(query, k=k)
        return [
            {
                'content': doc.page_content,
                'metadata': doc.metadata,
                'score': score
            }
            for doc, score in results
        ]