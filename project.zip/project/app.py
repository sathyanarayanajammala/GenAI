import gradio as gr
import os
from typing import Dict, List
from config import Config
from llm_handler import LLMHandler
from embeddings_handler import EmbeddingsHandler
from patent_processor import PatentProcessor

class PatentAdvisorUI:
    def __init__(self):
        self.config = Config()
        openai_api_key = os.getenv("OPENAI_API_KEY")
        
        self.llm = LLMHandler(self.config, openai_api_key)
        self.embeddings = EmbeddingsHandler(self.config)
        self.processor = PatentProcessor(self.config)
        
        # Load existing vector store if available
        if os.path.exists(self.config.vector_store_path):
            self.embeddings.load_vector_store()
            
    def analyze_patent(self, text: str) -> Dict:
        # Process and analyze patent
        summary = self.llm.generate_summary(text)
        concepts = self.llm.extract_concepts(text)
        similar = self.embeddings.search_similar(text)
        
        return {
            "summary": summary,
            "concepts": concepts,
            "similar": similar
        }
        
    def create_interface(self):
        # Define custom theme
        theme = gr.themes.Base().set(
            body_background_fill="#f8f9fa",
            block_background_fill="#ffffff",
            block_border_width="2px",
            block_border_color="#1a365d",
            block_radius="8px",
            button_primary_background_fill="#1a365d",
            button_primary_text_color="#ffffff",
        )
        
        # Create interface
        with gr.Blocks(theme=theme) as interface:
            gr.Markdown(
                """
                # AI Patent Advisor
                ### Powered by Advanced Language Models for Patent Analysis
                """
            )
            
            with gr.Row():
                with gr.Column(scale=2):
                    input_text = gr.Textbox(
                        label="Patent Text",
                        placeholder="Enter patent text here...",
                        lines=10
                    )
                    analyze_btn = gr.Button("Analyze Patent")
                    
                with gr.Column(scale=3):
                    summary_out = gr.Textbox(
                        label="Patent Summary",
                        lines=4
                    )
                    concepts_out = gr.Textbox(
                        label="Key Technical Concepts",
                        lines=2
                    )
                    similar_out = gr.Textbox(
                        label="Similar Patents",
                        lines=6
                    )
                    
            analyze_btn.click(
                fn=self.analyze_patent,
                inputs=input_text,
                outputs=[summary_out, concepts_out, similar_out]
            )
            
            # Add example patents
            gr.Examples(
                examples=[
                    ["A method for implementing AI-based predictive maintenance..."],
                    ["A system for renewable energy optimization using hybrid..."]
                ],
                inputs=input_text
            )
            
        return interface

def main():
    app = PatentAdvisorUI()
    interface = app.create_interface()
    interface.launch(share=True)

if __name__ == "__main__":
    main()