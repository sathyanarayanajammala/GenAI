from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

class SemanticMatcher:
    def __init__(self):
        self.commercial_applications_db = {
            'healthcare': ['medical devices', 'diagnostic tools', 'therapeutic applications'],
            'technology': ['software applications', 'hardware solutions', 'IoT devices'],
            'manufacturing': ['industrial processes', 'automation systems', 'quality control'],
            # Add more domains and applications
        }

    def find_matching_applications(self, patent_embedding):
        """Find matching commercial applications for a patent"""
        matches = []
        
        # Convert patent embedding to numpy array
        patent_vector = patent_embedding.cpu().numpy()
        
        # Compare with each domain and application
        for domain, applications in self.commercial_applications_db.items():
            # Simplified matching logic - in practice, you'd have embeddings for each application
            similarity_scores = cosine_similarity(
                patent_vector.reshape(1, -1),
                np.random.rand(len(applications), patent_vector.shape[0])  # Placeholder for actual application embeddings
            )
            
            # Get top matches
            top_indices = similarity_scores.argsort()[0][-3:][::-1]
            matches.extend([
                {
                    'domain': domain,
                    'application': applications[i],
                    'score': float(similarity_scores[0][i])
                }
                for i in top_indices if similarity_scores[0][i] > 0.5
            ])
        
        return sorted(matches, key=lambda x: x['score'], reverse=True)