from dataclasses import dataclass
from typing import Optional

@dataclass
class ModelConfig:
    gpt_neo_model: str = "EleutherAI/gpt-neo-125M"
    embedding_model: str = "sentence-transformers/all-mpnet-base-v2"
    max_length: int = 512
    batch_size: int = 16
    learning_rate: float = 2e-5
    num_epochs: int = 3

@dataclass
class ProcessingConfig:
    chunk_size: int = 1000
    chunk_overlap: int = 200
    max_tokens: int = 512

@dataclass
class Config:
    model: ModelConfig = ModelConfig()
    processing: ProcessingConfig = ProcessingConfig()
    vector_store_path: str = "patent_vectors"
    openai_model: str = "gpt-3.5-turbo"