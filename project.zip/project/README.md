# AI Patent Advisor

An AI-powered system for analyzing patents using GPT-Neo and LangChain, with FAISS vector storage for efficient similarity search.

## Features

- Patent text analysis and summarization using GPT-Neo
- Key concept extraction
- Vector similarity search using FAISS
- Commercial application recommendations
- User-friendly Gradio interface

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Train the model and build vector store:
   ```bash
   python train.py
   ```

2. Launch the web interface:
   ```bash
   python app.py
   ```

3. Access the interface through your web browser at the provided URL.

## System Components

- `data_processor.py`: Data loading and preprocessing with GPT-Neo tokenizer
- `patent_analyzer.py`: Patent analysis using GPT-Neo
- `vector_store.py`: FAISS vector storage implementation
- `app.py`: Gradio web interface
- `train.py`: Training and vector store building script

## Dataset

Uses the AI-Growth-Lab patents and claims dataset from Hugging Face.