from typing import List, Dict
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from config import Config

class PatentProcessor:
    def __init__(self, config: Config):
        self.config = config
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=config.processing.chunk_size,
            chunk_overlap=config.processing.chunk_overlap,
            length_function=len,
        )
        
        nltk.download('punkt')
        nltk.download('stopwords')
        self.stop_words = set(stopwords.words('english'))
        
    def clean_text(self, text: str) -> str:
        """Clean and normalize patent text"""
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        text = text.lower().strip()
        
        tokens = word_tokenize(text)
        text = ' '.join([
            token for token in tokens 
            if token not in self.stop_words
        ])
        
        return text
        
    def process_patent(self, text: str) -> List[Document]:
        """Process patent text into chunks"""
        cleaned_text = self.clean_text(text)
        chunks = self.text_splitter.split_text(cleaned_text)
        
        return [
            Document(
                page_content=chunk,
                metadata={'source': 'patent'}
            ) 
            for chunk in chunks
        ]
        
    def batch_process(self, patents: List[Dict]) -> List[Document]:
        """Process a batch of patents"""
        documents = []
        for patent in patents:
            text = patent.get('text', '')
            if text:
                docs = self.process_patent(text)
                for doc in docs:
                    doc.metadata.update(patent.get('metadata', {}))
                documents.extend(docs)
        return documents