from langchain_openai import ChatOpenAI
from langchain.chains.summarize import load_summarize_chain
from langchain.prompts import PromptTemplate
from langchain_core.documents import Document
from typing import List, Dict

class PatentAnalyzer:
    def __init__(self, openai_api_key: str):
        self.llm = ChatOpenAI(
            temperature=0.7,
            model="gpt-3.5-turbo",
            openai_api_key=openai_api_key
        )
        
        self.summary_prompt = PromptTemplate(
            template="""Write a concise summary of the following patent:
            "{text}"
            CONCISE SUMMARY:""",
            input_variables=["text"]
        )
        
        self.concepts_prompt = PromptTemplate(
            template="""Extract the key technical concepts from this patent:
            "{text}"
            
            Format the response as a comma-separated list of concepts.
            KEY CONCEPTS:""",
            input_variables=["text"]
        )

    def generate_summary(self, text: str) -> str:
        """Generate a summary of the patent text"""
        docs = [Document(page_content=text)]
        chain = load_summarize_chain(
            llm=self.llm,
            chain_type="stuff",
            prompt=self.summary_prompt
        )
        summary = chain.run(docs)
        return summary.strip()

    def extract_key_concepts(self, text: str) -> List[str]:
        """Extract key concepts from the patent text"""
        docs = [Document(page_content=text)]
        chain = load_summarize_chain(
            llm=self.llm,
            chain_type="stuff",
            prompt=self.concepts_prompt
        )
        concepts = chain.run(docs)
        return [concept.strip() for concept in concepts.split(",")]