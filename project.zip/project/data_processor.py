from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.llms import HuggingFaceHub
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from datasets import load_dataset
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import re

class DataProcessor:
    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(
            model_name="all-MiniLM-L6-v2",
            model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'}
        )
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
        )
        nltk.download('punkt')
        nltk.download('stopwords')
        self.stop_words = set(stopwords.words('english'))

    def load_dataset(self):
        """Load the AI-Growth-Lab patents dataset"""
        dataset = load_dataset("AI-Growth-Lab/patents_claims_1.5m_traim_test")
        return dataset

    def clean_text(self, text):
        """Clean and preprocess text data"""
        text = re.sub(r'[^\w\s]', '', text)
        text = re.sub(r'\d+', '', text)
        text = text.lower()
        word_tokens = word_tokenize(text)
        text = ' '.join([w for w in word_tokens if w not in self.stop_words])
        return text

    def process_text(self, text):
        """Process text into chunks and create documents"""
        cleaned_text = self.clean_text(text)
        chunks = self.text_splitter.split_text(cleaned_text)
        docs = [Document(page_content=chunk) for chunk in chunks]
        return docs

    def create_vector_store(self, documents):
        """Create FAISS vector store from documents"""
        return FAISS.from_documents(documents, self.embeddings)