from langchain_community.llms import HuggingFaceHub
from langchain_openai import ChatOpenAI
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from config import Config

class LLMHandler:
    def __init__(self, config: Config, openai_api_key: Optional[str] = None):
        self.config = config
        
        # Initialize GPT-Neo model
        self.gpt_neo = HuggingFaceHub(
            repo_id=config.model.gpt_neo_model,
            model_kwargs={"temperature": 0.7, "max_length": 512}
        )
        
        # Initialize OpenAI model if API key is provided
        self.openai = ChatOpenAI(
            temperature=0.7,
            model=config.openai_model,
            openai_api_key=openai_api_key
        ) if openai_api_key else None
        
        self._init_prompts()
        
    def _init_prompts(self):
        self.summary_prompt = PromptTemplate(
            template="""Analyze and summarize the following patent text:
            {text}
            
            Provide a concise summary focusing on:
            1. Core innovation
            2. Technical implementation
            3. Potential applications
            
            Summary:""",
            input_variables=["text"]
        )
        
        self.concepts_prompt = PromptTemplate(
            template="""Extract key technical concepts from this patent:
            {text}
            
            List the main technical concepts, separated by commas:""",
            input_variables=["text"]
        )
        
    def generate_summary(self, text: str) -> str:
        """Generate patent summary using available models"""
        chain = LLMChain(
            llm=self.openai if self.openai else self.gpt_neo,
            prompt=self.summary_prompt
        )
        return chain.run(text=text)
        
    def extract_concepts(self, text: str) -> list[str]:
        """Extract key concepts from patent text"""
        chain = LLMChain(
            llm=self.openai if self.openai else self.gpt_neo,
            prompt=self.concepts_prompt
        )
        concepts = chain.run(text=text)
        return [c.strip() for c in concepts.split(",")]