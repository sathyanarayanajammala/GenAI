from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from typing import List, Dict
import numpy as np

class VectorStore:
    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(
            model_name="all-MiniLM-L6-v2",
            model_kwargs={'device': 'cuda' if torch.cuda.is_available() else 'cpu'}
        )
        self.vector_store = None

    def create_store(self, documents):
        """Create a new vector store from documents"""
        self.vector_store = FAISS.from_documents(documents, self.embeddings)

    def add_documents(self, documents):
        """Add documents to the vector store"""
        if self.vector_store is None:
            self.create_store(documents)
        else:
            self.vector_store.add_documents(documents)

    def search(self, query: str, k: int = 5):
        """Search for similar patents"""
        if self.vector_store is None:
            return []
            
        results = self.vector_store.similarity_search_with_score(query, k=k)
        return [
            {
                'content': doc.page_content,
                'metadata': doc.metadata,
                'score': score
            }
            for doc, score in results
        ]

    def save_local(self, path: str):
        """Save the vector store locally"""
        self.vector_store.save_local(path)

    def load_local(self, path: str):
        """Load the vector store from local storage"""
        self.vector_store = FAISS.load_local(path, self.embeddings)