from datasets import load_dataset
from config import Config
from patent_processor import PatentProcessor
from embeddings_handler import EmbeddingsHandler
from tqdm import tqdm

def main():
    # Initialize components
    config = Config()
    processor = PatentProcessor(config)
    embeddings = EmbeddingsHandler(config)
    
    # Load dataset
    print("Loading AI-Growth-Lab patents dataset...")
    dataset = load_dataset("AI-Growth-Lab/patents_claims_1.5m_traim_test")
    
    # Process patents in batches
    batch_size = 100
    all_documents = []
    
    print("Processing patents...")
    for i in tqdm(range(0, len(dataset['train']), batch_size)):
        batch = dataset['train'][i:i + batch_size]
        
        # Convert to list of dictionaries
        patents = [
            {
                'text': item['claim_text'],
                'metadata': {
                    'application': item.get('application', ''),
                    'domain': item.get('domain', '')
                }
            }
            for item in batch
        ]
        
        # Process batch
        documents = processor.batch_process(patents)
        all_documents.extend(documents)
        
        # Update vector store periodically
        if len(all_documents) >= 1000:
            embeddings.init_vector_store(all_documents)
            all_documents = []
    
    # Process remaining documents
    if all_documents:
        embeddings.init_vector_store(all_documents)
    
    # Save vector store
    print("Saving vector store...")
    embeddings.save_vector_store()
    
    print("Training completed!")

if __name__ == "__main__":
    main()