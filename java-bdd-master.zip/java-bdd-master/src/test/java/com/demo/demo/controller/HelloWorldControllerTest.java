package com.demo.demo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class HelloWorldControllerTest {

    private HelloWorldController helloWorldController;
    @BeforeEach
    public void init(){
        helloWorldController=mock(HelloWorldController.class);
        when(helloWorldController.getHelloWorld()).thenReturn("Hello-World");
    }
    
    @Test
    public void doTest(){
        assertEquals(helloWorldController.getHelloWorld(), "Hello-World");
    }
}
