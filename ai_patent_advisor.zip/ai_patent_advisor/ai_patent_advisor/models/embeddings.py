"""Embedding and vector database utilities."""

from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS

from ..config.config import ModelConfig

def get_embeddings(config: ModelConfig = ModelConfig()):
    """Initialize embedding model."""
    return HuggingFaceEmbeddings(model_name=config.embedding_model)

def create_vectordb(docs, embeddings):
    """Create FAISS vector database from documents."""
    db = FAISS.from_texts(docs, embeddings)
    print(f"FAISS VectorDB created with {len(db.index_to_docstore_id)} vectors.")
    return db
