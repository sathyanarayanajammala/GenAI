# AI Patent Advisor

A Python package for patent analysis and advisory services using AI. This project provides tools for prior art search, patent summarization, competitive monitoring, and claim analysis.

## Features

- Prior Art Search
- Patent Summarization
- Competitive Monitoring
- Claim Analysis
- BERTScore-based Summary Evaluation

## Project Structure

```
ai_patent_advisor/
├── ai_patent_advisor/
│   ├── config/
│   │   └── config.py         # Configuration settings
│   ├── data/
│   │   └── data_loader.py    # Data loading utilities
│   ├── models/
│   │   └── embeddings.py     # Embedding and vector DB
│   ├── services/
│   │   └── patent_services.py # Main services
│   └── utils/                # Utility functions
├── tests/                    # Test files
├── requirements.txt          # Dependencies
└── README.md                # This file
```

## Installation

1. Clone the repository
2. Set up your API keys:
   - Create a `.env` file in the root directory
   - Add your API keys:
     ```plaintext
     OPENAI_API_KEY=your-openai-api-key-here
     HUGGINGFACEHUB_API_TOKEN=your-huggingface-api-token-here
     HF_TOKEN=your-huggingface-api-token-here
     ```
   - Never commit your API keys to version control
   - Note: If using Google Colab, the keys will be loaded automatically from userdata
3. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

```python
from ai_patent_advisor.services.patent_services import (
    prior_art_search,
    patent_summarization,
    competitive_monitoring,
    claim_analysis
)

# Example: Perform prior art search
result, metadata = prior_art_search("quantum computing encryption")

# Example: Summarize a patent
summary, metadata = patent_summarization(patent_text)

# Example: Monitor competition
report, metadata = competitive_monitoring("artificial intelligence")

# Example: Analyze claims
analysis, metadata = claim_analysis(claim1, claim2)
```

## Configuration

You can customize the behavior by modifying the configuration classes in `config/config.py`:

- `ModelConfig`: Embedding and language model settings
- `DataConfig`: Dataset and processing parameters
- `MemoryConfig`: Conversation memory settings

## Dependencies

- datasets
- langchain
- sentence-transformers
- faiss-cpu
- tqdm
- torch
- transformers
- bert-score

## License

This project is licensed under the MIT License.
