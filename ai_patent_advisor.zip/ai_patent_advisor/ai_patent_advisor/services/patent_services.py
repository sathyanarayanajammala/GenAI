"""Patent advisory services."""

from langchain.memory import ConversationBufferWindowMemory
from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain

from ..config.config import ModelConfig, MemoryConfig

def get_qa_chain(memory, model_config: ModelConfig = ModelConfig()):
    """Create QA chain with memory."""
    llm = ChatOpenAI(
        model_name=model_config.llm_model,
        temperature=model_config.temperature,
        max_tokens=model_config.max_tokens
    )
    
    retriever = db.as_retriever(
        search_type="mmr",
        search_kwargs={"k": 2, "fetch_k": 5}
    )
    
    qa_chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=retriever,
        memory=memory,
        return_source_documents=True
    )
    return qa_chain

def get_memory(config: MemoryConfig = MemoryConfig()):
    """Initialize conversation memory."""
    return ConversationBufferWindowMemory(
        memory_key=config.memory_key,
        return_messages=config.return_messages,
        k=config.window_size,
        output_key=config.output_key
    )

def get_retrieved_docs_metadata(result):
    """Extract metadata from retrieved documents."""
    retrieved_docs_metadata = ""
    if 'source_documents' in result:
        for doc in result['source_documents']:
            if hasattr(doc, 'metadata'):
                retrieved_docs_metadata += f"Metadata: {doc.metadata}\n"
    return retrieved_docs_metadata

def prior_art_search(query, memory=None):
    """Perform prior art search."""
    if memory is None:
        memory = get_memory()
    qa_chain = get_qa_chain(memory)
    result = qa_chain({"question": query})
    retrieved_docs_metadata = get_retrieved_docs_metadata(result)
    return result["answer"], retrieved_docs_metadata

def patent_summarization(patent_text, memory=None):
    """Summarize patent text."""
    if memory is None:
        memory = get_memory()
    qa_chain = get_qa_chain(memory)
    result = qa_chain({"question": f"Summarize this patent:\n{patent_text}"})
    retrieved_docs_metadata = get_retrieved_docs_metadata(result)
    return result["answer"], retrieved_docs_metadata

def competitive_monitoring(technology_area, memory=None):
    """Monitor patents in specific technology area."""
    if memory is None:
        memory = get_memory()
    qa_chain = get_qa_chain(memory)
    result = qa_chain({"question": f"Summarize recent patents in {technology_area}"})
    retrieved_docs_metadata = get_retrieved_docs_metadata(result)
    return result["answer"], retrieved_docs_metadata

def claim_analysis(claim1, claim2, memory=None):
    """Compare and analyze patent claims."""
    if memory is None:
        memory = get_memory()
    qa_chain = get_qa_chain(memory)
    result = qa_chain({
        "question": f"Compare and contrast these two claims:\nClaim 1: {claim1}\nClaim 2: {claim2}"
    })
    retrieved_docs_metadata = get_retrieved_docs_metadata(result)
    return result["answer"], retrieved_docs_metadata
