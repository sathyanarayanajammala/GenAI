"""Data loading and processing utilities."""

from datasets import load_dataset
from langchain.text_splitter import RecursiveCharacterTextSplitter
from tqdm import tqdm

from ..config.config import DataConfig

def load_patent_data(config: DataConfig = DataConfig()):
    """Load patent dataset based on configuration."""
    dataset = load_dataset(
        config.dataset_name,
        config.dataset_subset,
        trust_remote_code=True,
        split=f"train[:{config.sample_size}]"
    )
    return dataset["description"]

def create_text_chunks(texts, config: DataConfig = DataConfig()):
    """Split texts into chunks for processing."""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=config.chunk_size,
        chunk_overlap=config.chunk_overlap
    )
    
    docs = []
    for text in tqdm(texts, desc="Creating chunks"):
        chunks = text_splitter.split_text(text)
        docs.extend(chunks)
    
    return docs
