"""Configuration settings for the AI Patent Advisor."""

from dataclasses import dataclass
from typing import Optional

@dataclass
class ModelConfig:
    """Configuration for the model settings."""
    embedding_model: str = "sentence-transformers/all-mpnet-base-v2"
    llm_model: str = "gpt-4o-mini"
    temperature: float = 0.2
    max_tokens: int = 128

@dataclass
class DataConfig:
    """Configuration for data processing."""
    dataset_name: str = "big_patent"
    dataset_subset: str = "g"
    sample_size: int = 100
    chunk_size: int = 500
    chunk_overlap: int = 50

@dataclass
class MemoryConfig:
    """Configuration for conversation memory."""
    memory_key: str = "chat_history"
    return_messages: bool = True
    window_size: int = 3
    output_key: str = "answer"

# Default configurations
DEFAULT_MODEL_CONFIG = ModelConfig()
DEFAULT_DATA_CONFIG = DataConfig()
DEFAULT_MEMORY_CONFIG = MemoryConfig()
